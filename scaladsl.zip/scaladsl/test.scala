import scaladsl.Lang._

/*(new Identity('services)).namespace {

}*/

'services namespace {
  
  'user struct {
    'forename required 'string
    'surname required 'string
  }

  'phone_number enum {
    'beeline is 99777888
    'vivacell is 96888777
  }

  'authentication namespace {

    'user struct {
      'forename required 'string
      'surname required 'string
    }

    'login_request struct {
      'username required 'string
      'password required 'float
    }

    'login_reply struct {
      'user1 required 'services :: 'authentication :: 'user
    }
  }

}
