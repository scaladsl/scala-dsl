package scaladsl

import scala.collection.mutable.ListBuffer
import scala.collection.mutable.Stack

/*
begin <type> <name>
set <name> <value>
end
 */

object Lang {

  case class Attribute(val name: String, val value: String)

  object AST {

    case class Node(val name: String, val parent: Node) {
      val children: ListBuffer[Node] = ListBuffer[Node]()
      val attributes: ListBuffer[Attribute] = ListBuffer[Attribute]()

      def fullName(): String = {
        if ( parent == AST.root )
          s"$name"
        else
          s"${parent.fullName}::$name"
      }

      def find(name: String): Option[Node] = children.find(_.name == name)
    }

    val root: Node = Node("__root__", null)
    root.children.append(
      Node("string", root),
      Node("bool", root),
      Node("int", root),
      Node("float", root))

    val context = Stack[Node](root)
    def resolve(name: String): Node = {
      val path = name.split('.').toList

      val res = if ( path.size > 1 ) {
        findByPath(root, path)
      } else {
        findRecursively(context.top.parent, name)
      }

      if ( res == null )
        throw new IllegalArgumentException(s"unknown type name: $name")

      res
    }

    def findByPath(current: Node, path: List[String]): Node = {
      current.find(path.head) match {
        case Some(child) =>
          if ( path.size == 1 )
            child
          else
            findByPath(child, path.tail)

        case None =>
          null
      }
    }

    def scope(name: String)(block: Node => Unit): Unit = {
      val node = Node(name, AST.context.top)
      AST.context.top.children.append(node)
      AST.context.push(node)

      block(node)

      AST.context.pop
    }

    private def findRecursively(current: Node, name: String): Node = {
      if ( current != null ) {
        current.find(name) match {
          case Some(node) => node
          case None => findRecursively(current.parent, name)
        }
      } else {
        null
      }
    }
  }

  implicit class Identity(val id: Symbol) {

    def name = id.name

    def ::(other: Identity): Identity = new Identity(Symbol(s"${other.name}.${name}"))

    def namespace(block: => Unit): Unit = {
      AST.scope(name) { _ =>
        block
      }
    }

    def struct(block: => Unit): Unit = {
      AST.scope(name) { _ =>
        block
      }
    }

    def enum(block: => Unit): Unit = {
      AST.scope(name) { _ =>
        block
      }
    }

    def required(datatype: Identity): Unit = {
      AST.scope(name) { node =>
        val typeNode = AST.resolve(datatype.name)
        node.attributes.append(Attribute("datatype", typeNode.fullName))
      }
    }

    def optional(datatype: Identity): Unit = {
      AST.scope(name) { node =>
        val typeNode = AST.resolve(datatype.name)
        node.attributes.append(Attribute("datatype", typeNode.fullName))
      }
    }

    def repeated(datatype: Identity): Unit = {
      AST.scope(name) { node =>
        val typeNode = AST.resolve(datatype.name)
        node.attributes.append(Attribute("datatype", typeNode.fullName))
      }
    }

    def is(value: Int): Unit = {
      AST.scope(name) { node =>
        node.attributes.append(Attribute("value", value.toString))
      }
    }
  }
}
